<div class="post">
	<h2>&raquo;Backup Data</h2>
	<div class="entry">
		<p>
		
		
		E-Accounting adalah sebuah Aplikasi akuntansi berbasis web yang digunakan untuk mengelola laporan keuangan sesuai dengan siklus akuntansi
		seperti Pencatatan, Penggolongan, Pengikhtisaran, dan Pelaporan.
		
		
		
		</p>
	</div>
</div>
